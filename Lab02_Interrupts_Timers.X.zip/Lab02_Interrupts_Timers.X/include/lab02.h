#ifndef __LAB01_H__
#define	__LAB01_H__

void initialize_timer(void);

void timer_loop(void);

#endif	/* __LAB01_H__ */
