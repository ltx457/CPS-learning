#include "lab02.h"

#include <xc.h>
#define FCY 12800000UL
#include <libpic30.h>
#include <stdint.h>

#include "types.h"
#include "lcd.h"
#include "led.h"

#define FCY_EXT 32768UL
#define LOOP_ITERATIONS 2000U

// Time counters, updated by interrupts
volatile unsigned int seconds = 0;
volatile unsigned int milliseconds = 0;



// Initialize Timer1, Timer2, and Timer3

void initialize_timer(void)
{
    // Enable secondary oscillator (32.768 kHz)
    __builtin_write_OSCCONL(OSCCON | 0x02);

    // ---------- Timer1: 1 second ----------
    T1CONbits.TON = 0;
    T1CONbits.TCKPS = 3;   // 1:256 prescaler
    T1CONbits.TCS = 1;     // External clock
    T1CONbits.TGATE = 0;   // Disable gated timer
    T1CONbits.TSYNC = 0;   // Disable synchronization

    PR1 = 127;             // 32768 / 256 = 128 Hz
    TMR1 = 0;

    IPC0bits.T1IP = 4;
    IFS0bits.T1IF = 0;
    IEC0bits.T1IE = 1;

    // ---------- Timer2: 2 milliseconds ----------
    T2CONbits.TON = 0;
    T2CONbits.T32 = 0;     // 16-bit mode
    T2CONbits.TCKPS = 3;   // 1:256 prescaler
    T2CONbits.TCS = 0;     // Internal clock
    T2CONbits.TGATE = 0;   // Disable gated timer

    PR2 = 99;              // 2 ms at FCY = 12.8 MHz
    TMR2 = 0;

    IPC1bits.T2IP = 5;
    IFS0bits.T2IF = 0;
    IEC0bits.T2IE = 1;

    // ---------- Timer3: execution measurement ----------
    T3CONbits.TON = 0;
    T3CONbits.TCKPS = 0;   // 1:1 prescaler
    T3CONbits.TCS = 0;     // Internal clock
    T3CONbits.TGATE = 0;   // Disable gated timer

    PR3 = 0xFFFF;          // Maximum 16-bit value
    TMR3 = 0;

    IFS0bits.T3IF = 0;
    IEC0bits.T3IE = 0;     // No Timer3 interrupt needed

    // Start Timer1 and Timer2
    T1CONbits.TON = 1;
    T2CONbits.TON = 1;
}



// Timer1 interrupt: every 1 second

void __attribute__((__interrupt__, __shadow__,
                    __auto_psv__)) _T1Interrupt(void)
{
    // Toggle LED2 every second
    //TOGGLELED(LED2);
      LATAbits.LATA5= !LATAbits.LATA5;


      
      
    seconds++;

    // Clear Timer1 interrupt flag
    IFS0bits.T1IF = 0;
}



// Timer2 interrupt: every 2 milliseconds

void __attribute__((__interrupt__, __shadow__,
                    __auto_psv__)) _T2Interrupt(void)
{
    // Toggle LED1 every 2 milliseconds
    //TOGGLELED(LED1);
      LATAbits.LATA4= !LATAbits.LATA4;

    // Count milliseconds
    milliseconds += 2;

    if (milliseconds >= 1000)
    {
        milliseconds = 0;
    }

    // Clear Timer2 interrupt flag
    IFS0bits.T2IF = 0;
}


// ==========================================
// Main experiment loop
// ==========================================
void timer_loop(void)
{
    unsigned int i;
    unsigned int ticks;
    unsigned int sec_snapshot;
    unsigned int ms_snapshot;

    uint32_t time_scaled;
    unsigned int time_integer;
    unsigned int time_fraction;

    // Reset Timer3
    T3CONbits.TON = 0;
    TMR3 = 0;

    while (1)
    {
        // Reset and start the measurement timer
        T3CONbits.TON = 0;
        TMR3 = 0;
        T3CONbits.TON = 1;

        // Execute 2000 iterations
        for (i = 0; i < LOOP_ITERATIONS; i++)
        {
            Nop();
        }

        // Stop Timer3 after 2000 iterations
        T3CONbits.TON = 0;

        // Read Timer3
        ticks = TMR3;

        // Toggle LED3 once per 2000 iterations
        //TOGGLELED(LED3);
          LATAbits.LATA9= !LATAbits.LATA9;

        // Snapshot the uptime
        sec_snapshot = seconds;
        ms_snapshot = milliseconds;

        // Convert ticks to milliseconds
        // Milliseconds x 10000 = ticks x 25 / 32
        time_scaled =
            ((uint32_t)ticks * 25UL + 16UL) / 32UL;

        time_integer =
            (unsigned int)(time_scaled / 10000UL);

        time_fraction =
            (unsigned int)(time_scaled % 10000UL);

        // LCD row 1: uptime (mm:ss.xxx)
        lcd_locate(0, 0);
        lcd_printf("Up %02u:%02u.%03u    ",
                   (sec_snapshot / 60U) % 100U,
                   sec_snapshot % 60U,
                   ms_snapshot);

        // LCD row 2: timer counts and elapsed ms
        lcd_locate(0, 1);
        lcd_printf("%05u %u.%04ums  ",
                   ticks,
                   time_integer,
                   time_fraction);
    }
}
