#include "led.h"

void led_init(void){
	CLEARBIT(LED1_TRIS); // set Pin to Output
	Nop();
	CLEARBIT(LED2_TRIS); // set Pin to Output
	Nop();
	CLEARBIT(LED3_TRIS); // set Pin to Output
	Nop();
	CLEARBIT(LED4_TRIS); // set Pin to Output
	Nop();
	CLEARBIT(LED5_TRIS); // set Pin to Output
	Nop();

    LATAbits.LATA4=0;
    LATAbits.LATA5=0;
    LATAbits.LATA9=0;
    LATAbits.LATA10=0;
    LATAbits.LATA0=0;
    }
