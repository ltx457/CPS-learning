#include <xc.h>

#define FCY 12800000UL
#include <libpic30.h>

#include "lcd.h"
#include "led.h"
#include "lab02.h"

// ==========================================
// Chip configuration
// ==========================================

// Primary oscillator with PLL
#pragma config FNOSC = PRIPLL

// XT crystal oscillator mode
#pragma config POSCMD = XT

// OSC2 pin functions as clock output
#pragma config OSCIOFNC = ON

// Disable watchdog timer
#pragma config FWDTEN = OFF


// ==========================================
// Main program
// ==========================================
int main(void)
{
    // Initialize LCD
    lcd_initialize();

    // Initialize LED pins
    led_init();

    // Clear LCD
    lcd_clear();

    // Set initial cursor position
    lcd_locate(0, 0);

    // Initialize Timer1, Timer2, Timer3
    initialize_timer();

    // Start the lab experiment
    timer_loop();

    // Should never reach here
    while (1)
    {
        Nop();
    }

    return 0;
}